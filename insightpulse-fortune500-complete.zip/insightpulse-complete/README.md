# InsightPulse AI - Fortune 500 Ready ERP

[![License: AGPL-3](https://img.shields.io/badge/License-AGPL%203-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
[![Odoo Version](https://img.shields.io/badge/Odoo-18.0%20CE-blueviolet)](https://www.odoo.com)
[![SOC 2 Ready](https://img.shields.io/badge/SOC%202-Ready-green)](https://docs.insightpulseai.net/security)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue)](https://github.com/jgtolentino/odoo-ce/pkgs/container/odoo-ce)

## Overview

Complete Enterprise ERP platform achieving **SAP S/4HANA + CA Clarity PPM + SAP Concur** parity at **99% cost savings**.

| SaaS Replaced | Annual Cost | InsightPulse | Savings |
|---------------|-------------|--------------|---------|
| SAP S/4HANA | $920,000 | $0 | 100% |
| CA Clarity PPM | $150,000 | $0 | 100% |
| SAP Concur | $15,000 | $0 | 100% |
| SAP Ariba | $12,000 | $0 | 100% |
| **TOTAL** | **$1,097,000** | **~$5,000** | **99.5%** |

## Gap Closure Summary

This image closes **707 hours** of enterprise gaps:

| Workstream | Gaps | Hours | Status |
|------------|------|-------|--------|
| B: Finance SSC | B1-B4 | 156h | ✅ Closed |
| C: BIR Compliance | C1-C5 | 153h | ✅ Closed |
| D: PPM/Projects | D1-D5 | 176h | ✅ Closed |
| E: Automation | E2-E4 | 60h | ✅ Closed |
| F: Security | F1-F5 | 162h | ✅ Closed |

## Modules Included

### Finance SSC (`ipai_finance_ssc`)
- ✅ B1-01: Philippine Chart of Accounts (PSCA)
- ✅ B2-01: 15-step Month-End Closing Checklist
- ✅ B2-04: Closing Journal Entry Wizard
- ✅ B3-*: Financial Reports (TB, BS, P&L, CF)
- ✅ B4-*: Intercompany Transaction Management

### BIR Compliance (`ipai_bir_compliance`)
- ✅ C1-01: Form 1601-C (Monthly WHT)
- ✅ C1-04: DAT File Generator for eFPS
- ✅ C2-*: Form 2550Q (Quarterly VAT)
- ✅ C3-*: Form 1702 (Annual ITR)
- ✅ C4-*: Form 2307 (WHT Certificates)

### PPM Advanced (`ipai_ppm_advanced`)
- ✅ D1-01: WBS Auto-Numbering
- ✅ D2-01: RAG Status Indicators (Schedule/Budget/Scope)
- ✅ D3-*: Resource Management & Capacity Planning
- ✅ D4-*: Financial Planning & EVM (BCWS, BCWP, CPI, SPI)
- ✅ D5-*: Portfolio Management

## Quick Start

### Using Pre-built Image

```bash
# Pull the image
docker pull ghcr.io/jgtolentino/odoo-ce:v2.0.0-fortune500

# Run with Docker Compose
curl -O https://raw.githubusercontent.com/jgtolentino/odoo-ce/main/docker-compose.yml
docker compose up -d

# Access at https://erp.insightpulseai.net (or localhost:8069)
```

### Build from Source

```bash
# Clone repository
git clone https://github.com/jgtolentino/odoo-ce.git
cd odoo-ce

# Build image
docker build -t insightpulse-odoo:v2.0.0-fortune500 .

# Run
docker compose up -d
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    INSIGHTPULSE AI PLATFORM                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐         │
│  │   Traefik       │  │   Odoo 18 CE    │  │   n8n           │         │
│  │   (TLS/Proxy)   │──│   + ipai_*      │──│   (Workflows)   │         │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘         │
│                              │                                          │
│                              │                                          │
│                       ┌──────┴──────┐                                  │
│                       │ PostgreSQL  │                                  │
│                       │    16       │                                  │
│                       └─────────────┘                                  │
│                                                                         │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐         │
│  │   Superset      │  │   Prometheus    │  │   Grafana       │         │
│  │   (BI)          │  │   (Metrics)     │  │   (Dashboards)  │         │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘         │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## Security (SOC 2 / ISO 27001)

| Control | Implementation |
|---------|----------------|
| Access Control | Odoo RBAC + PostgreSQL RLS |
| Encryption | TLS 1.3 + AES-256 at rest |
| Audit Logging | `mail.message` + custom audit trail |
| Session Management | Redis + 30-min timeout |
| Input Validation | Odoo ORM + API validation |
| Container Security | Non-root user, minimal base |
| Network Security | Traefik WAF, rate limiting |
| Secret Management | Environment variables (Vault-ready) |

## Environment Variables

```bash
# Database
DB_PASSWORD=your-secure-password

# n8n
N8N_USER=admin
N8N_PASSWORD=your-secure-password
N8N_ENCRYPTION_KEY=your-32-char-key

# Superset
SUPERSET_SECRET_KEY=your-secret-key

# Grafana
GRAFANA_PASSWORD=your-secure-password
```

## Deployment to DigitalOcean

```bash
# Create droplet
doctl compute droplet create insightpulse-erp \
  --region sgp1 \
  --size s-4vcpu-8gb \
  --image docker-20-04

# SSH and deploy
ssh root@your-droplet-ip
git clone https://github.com/jgtolentino/odoo-ce.git
cd odoo-ce
docker compose up -d
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/web/health` | GET | Health check |
| `/api/v1/bir/1601c` | GET/POST | BIR Form 1601-C |
| `/api/v1/bir/2307` | GET/POST | BIR Form 2307 |
| `/api/v1/ppm/projects` | GET | Project list |
| `/api/v1/ppm/portfolio` | GET | Portfolio dashboard |

## Support

- **Documentation:** https://docs.insightpulseai.net
- **GitHub Issues:** https://github.com/jgtolentino/odoo-ce/issues
- **Email:** support@insightpulseai.net

## License

AGPL-3.0 - See [LICENSE](LICENSE)

---

**InsightPulse AI** - Enterprise ERP at startup cost.
