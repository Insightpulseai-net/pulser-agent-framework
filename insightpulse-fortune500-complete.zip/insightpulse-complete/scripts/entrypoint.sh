#!/bin/bash
# =============================================================================
# INSIGHTPULSE AI - ENTERPRISE ENTRYPOINT
# =============================================================================
# Handles:
#   - Database initialization
#   - Module auto-upgrade
#   - Health check endpoint setup
#   - Graceful shutdown
# =============================================================================

set -e

# Colors for logging
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# =============================================================================
# WAIT FOR DATABASE
# =============================================================================
wait_for_db() {
    log_info "Waiting for database at ${HOST}:${PORT}..."
    
    for i in {1..30}; do
        if pg_isready -h "${HOST}" -p "${PORT}" -U "${USER}" > /dev/null 2>&1; then
            log_info "Database is ready!"
            return 0
        fi
        log_warn "Database not ready yet (attempt $i/30)..."
        sleep 2
    done
    
    log_error "Database connection failed after 30 attempts"
    exit 1
}

# =============================================================================
# CHECK IF DATABASE EXISTS
# =============================================================================
db_exists() {
    PGPASSWORD="${PASSWORD}" psql -h "${HOST}" -p "${PORT}" -U "${USER}" -lqt | cut -d \| -f 1 | grep -qw "${DATABASE}"
}

# =============================================================================
# INITIALIZE DATABASE
# =============================================================================
init_database() {
    if ! db_exists; then
        log_info "Initializing database: ${DATABASE}"
        
        # Create database with demo data disabled
        odoo -c "${ODOO_RC}" \
            -d "${DATABASE}" \
            --init base \
            --without-demo=all \
            --stop-after-init \
            --no-http
        
        log_info "Database initialized successfully"
    else
        log_info "Database ${DATABASE} already exists"
    fi
}

# =============================================================================
# AUTO-UPGRADE MODULES
# =============================================================================
auto_upgrade_modules() {
    if [ "${AUTO_UPGRADE}" = "true" ]; then
        log_info "Auto-upgrading IPAI modules..."
        
        # Core modules to upgrade (in dependency order)
        MODULES="ipai_finance_ssc,ipai_bir_compliance,ipai_ppm_advanced"
        
        # Check if modules are installed, then upgrade
        for module in $(echo $MODULES | tr ',' ' '); do
            # Check if module exists in addons path
            if [ -d "/mnt/extra-addons/${module}" ]; then
                log_info "Upgrading module: ${module}"
                odoo -c "${ODOO_RC}" \
                    -d "${DATABASE}" \
                    -u "${module}" \
                    --stop-after-init \
                    --no-http 2>&1 || log_warn "Module ${module} upgrade skipped (not installed)"
            fi
        done
        
        log_info "Module upgrade complete"
    else
        log_info "Auto-upgrade disabled, skipping..."
    fi
}

# =============================================================================
# INSTALL MODULES (First Run)
# =============================================================================
install_modules() {
    log_info "Installing IPAI modules..."
    
    # Install all custom modules
    MODULES="ipai_finance_ssc,ipai_bir_compliance,ipai_ppm_advanced"
    
    odoo -c "${ODOO_RC}" \
        -d "${DATABASE}" \
        -i "${MODULES}" \
        --without-demo=all \
        --stop-after-init \
        --no-http || log_warn "Some modules may already be installed"
    
    log_info "Module installation complete"
}

# =============================================================================
# GRACEFUL SHUTDOWN
# =============================================================================
graceful_shutdown() {
    log_info "Received shutdown signal, stopping gracefully..."
    kill -SIGTERM "$child" 2>/dev/null
    wait "$child"
    exit 0
}

trap graceful_shutdown SIGTERM SIGINT

# =============================================================================
# MAIN
# =============================================================================
main() {
    log_info "Starting InsightPulse AI Odoo v2.0.0-fortune500"
    log_info "Environment: DATABASE=${DATABASE}, HOST=${HOST}, WORKERS=${WORKERS}"
    
    # Wait for database
    wait_for_db
    
    # Initialize or upgrade
    if [ "$1" = "odoo" ]; then
        init_database
        
        # First run: install modules
        if [ "${INSTALL_MODULES}" = "true" ]; then
            install_modules
        fi
        
        # Auto-upgrade on every start
        auto_upgrade_modules
        
        log_info "Starting Odoo server..."
        exec odoo -c "${ODOO_RC}" \
            --addons-path="${ADDONS_PATH}" \
            --workers="${WORKERS:-4}" \
            --max-cron-threads="${MAX_CRON_THREADS:-2}" \
            --limit-memory-hard="${LIMIT_MEMORY_HARD:-4294967296}" \
            --limit-memory-soft="${LIMIT_MEMORY_SOFT:-2147483648}" \
            --limit-time-cpu="${LIMIT_TIME_CPU:-600}" \
            --limit-time-real="${LIMIT_TIME_REAL:-1200}" &
        
        child=$!
        wait "$child"
    else
        # Pass through any other command
        exec "$@"
    fi
}

main "$@"
