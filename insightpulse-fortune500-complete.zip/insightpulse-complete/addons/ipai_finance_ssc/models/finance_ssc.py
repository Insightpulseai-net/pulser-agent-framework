# -*- coding: utf-8 -*-
"""
IPAI Finance SSC - Core Models
Closes gaps: B1-01 (Chart of Accounts PH), B2-01 (Closing Checklist), 
             B2-04 (Closing Journal Wizard), B3-*, B4-*
"""
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from datetime import date, timedelta
import logging

_logger = logging.getLogger(__name__)


# =============================================================================
# B1: CHART OF ACCOUNTS - PHILIPPINE GAAP (P0 BLOCKER - 4h)
# =============================================================================
class AccountAccountPH(models.Model):
    """Extends account.account with Philippine GAAP fields"""
    _inherit = 'account.account'

    # BIR Classification
    bir_classification = fields.Selection([
        ('asset', 'Assets'),
        ('liability', 'Liabilities'),
        ('equity', 'Equity'),
        ('income', 'Income'),
        ('cost', 'Cost of Sales/Services'),
        ('expense', 'Operating Expenses'),
        ('other_income', 'Other Income'),
        ('other_expense', 'Other Expense'),
    ], string='BIR Classification', index=True)
    
    # Philippine Standard Chart of Accounts (PSCA) code
    psca_code = fields.Char(string='PSCA Code', size=10, index=True,
                           help='Philippine Standard Chart of Accounts code')
    
    # BIR ATC (Alpha-numeric Tax Code) mapping
    bir_atc_id = fields.Many2one('ipai.bir.atc', string='BIR ATC',
                                 help='Alpha-numeric Tax Code for BIR reporting')
    
    # Consolidation
    consolidation_account_id = fields.Many2one(
        'account.account', string='Consolidation Account',
        help='Parent account for consolidated reporting')
    
    # Intercompany flag
    is_intercompany = fields.Boolean(string='Intercompany Account')

    @api.constrains('psca_code')
    def _check_psca_code_format(self):
        """Validate PSCA code format: X-XXX-XXX"""
        for account in self:
            if account.psca_code:
                import re
                if not re.match(r'^[1-9]-\d{3}-\d{3}$', account.psca_code):
                    raise ValidationError(
                        "PSCA Code must follow format: X-XXX-XXX (e.g., 1-000-001)")


class BirAtc(models.Model):
    """BIR Alpha-numeric Tax Code master"""
    _name = 'ipai.bir.atc'
    _description = 'BIR Alpha-numeric Tax Code'
    _order = 'code'

    code = fields.Char(string='ATC Code', required=True, index=True)
    name = fields.Char(string='Description', required=True)
    tax_type = fields.Selection([
        ('wht', 'Withholding Tax'),
        ('vat', 'Value Added Tax'),
        ('percentage', 'Percentage Tax'),
        ('excise', 'Excise Tax'),
        ('dst', 'Documentary Stamp Tax'),
    ], string='Tax Type', required=True)
    rate = fields.Float(string='Rate (%)', digits=(5, 2))
    active = fields.Boolean(default=True)

    _sql_constraints = [
        ('code_unique', 'UNIQUE(code)', 'ATC Code must be unique!'),
    ]


# =============================================================================
# B2: MONTH-END CLOSING (P1 - 40h)
# =============================================================================
class FinanceClosingPeriod(models.Model):
    """Finance closing period with checklist"""
    _name = 'ipai.finance.closing'
    _description = 'Finance Closing Period'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'period_end desc'

    name = fields.Char(string='Reference', required=True, tracking=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)
    
    # Period
    period_start = fields.Date(string='Period Start', required=True)
    period_end = fields.Date(string='Period End', required=True)
    fiscal_year_id = fields.Many2one('account.fiscal.year', string='Fiscal Year')
    
    # Status
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('review', 'Under Review'),
        ('closed', 'Closed'),
        ('reopened', 'Reopened'),
    ], default='draft', tracking=True)
    
    # Checklist
    checklist_ids = fields.One2many('ipai.finance.closing.item', 'closing_id',
                                    string='Checklist Items')
    checklist_progress = fields.Float(compute='_compute_progress', store=True)
    
    # Dates
    target_close_date = fields.Date(string='Target Close Date')
    actual_close_date = fields.Date(string='Actual Close Date')
    
    # Responsible
    preparer_id = fields.Many2one('res.users', string='Preparer')
    reviewer_id = fields.Many2one('res.users', string='Reviewer')
    approver_id = fields.Many2one('res.users', string='Approver')

    @api.depends('checklist_ids.is_complete')
    def _compute_progress(self):
        for closing in self:
            total = len(closing.checklist_ids)
            if total:
                complete = len(closing.checklist_ids.filtered('is_complete'))
                closing.checklist_progress = (complete / total) * 100
            else:
                closing.checklist_progress = 0

    def action_start_closing(self):
        """Start the closing process and generate checklist"""
        self.ensure_one()
        if not self.checklist_ids:
            self._generate_checklist()
        self.write({'state': 'in_progress'})
        _logger.info(f"Started closing {self.name} for {self.company_id.name}")

    def action_submit_review(self):
        """Submit for review"""
        self.ensure_one()
        incomplete = self.checklist_ids.filtered(lambda x: not x.is_complete)
        if incomplete:
            raise UserError(f"{len(incomplete)} checklist items are incomplete!")
        self.write({'state': 'review'})

    def action_close_period(self):
        """Close the period"""
        self.ensure_one()
        self.write({
            'state': 'closed',
            'actual_close_date': fields.Date.today()
        })
        # Lock the period in Odoo
        self._lock_fiscal_period()

    def action_reopen(self):
        """Reopen closed period (requires approval)"""
        self.ensure_one()
        if self.env.user != self.approver_id and not self.env.user.has_group('account.group_account_manager'):
            raise UserError("Only approver or Finance Manager can reopen closed periods")
        self.write({'state': 'reopened'})
        self._unlock_fiscal_period()
        _logger.warning(f"Period {self.name} reopened by {self.env.user.name}")

    def _generate_checklist(self):
        """Generate standard 15-step closing checklist"""
        checklist_template = self.env['ipai.finance.closing.template'].search([
            ('company_id', '=', self.company_id.id)
        ], limit=1)
        
        if not checklist_template:
            # Use default checklist
            items = [
                (1, 'Bank Reconciliation', 'finance', 2),
                (2, 'AR Aging Review', 'finance', 1),
                (3, 'AP Aging Review', 'finance', 1),
                (4, 'Inventory Valuation', 'finance', 3),
                (5, 'Fixed Asset Depreciation', 'finance', 4),
                (6, 'Prepaid Expenses Amortization', 'finance', 5),
                (7, 'Accrued Expenses Review', 'finance', 6),
                (8, 'Revenue Recognition', 'finance', 7),
                (9, 'Intercompany Reconciliation', 'finance', 8),
                (10, 'Tax Provision Calculation', 'tax', 9),
                (11, 'WHT Reconciliation', 'tax', 10),
                (12, 'Trial Balance Review', 'reporting', 11),
                (13, 'Journal Entry Review', 'reporting', 12),
                (14, 'Financial Statements Prep', 'reporting', 13),
                (15, 'Manager Sign-off', 'approval', 14),
            ]
            for seq, name, category, depends in items:
                self.env['ipai.finance.closing.item'].create({
                    'closing_id': self.id,
                    'sequence': seq,
                    'name': name,
                    'category': category,
                    'depends_on_sequence': depends,
                })

    def _lock_fiscal_period(self):
        """Lock the accounting period"""
        # Implementation depends on Odoo account module configuration
        pass

    def _unlock_fiscal_period(self):
        """Unlock the accounting period"""
        pass


class FinanceClosingItem(models.Model):
    """Individual checklist item for closing"""
    _name = 'ipai.finance.closing.item'
    _description = 'Finance Closing Checklist Item'
    _order = 'closing_id, sequence'

    closing_id = fields.Many2one('ipai.finance.closing', string='Closing',
                                 required=True, ondelete='cascade')
    sequence = fields.Integer(string='Sequence', default=10)
    name = fields.Char(string='Task', required=True)
    
    category = fields.Selection([
        ('finance', 'Finance'),
        ('tax', 'Tax'),
        ('reporting', 'Reporting'),
        ('approval', 'Approval'),
    ], string='Category', required=True)
    
    # Status
    is_complete = fields.Boolean(string='Complete')
    completed_by = fields.Many2one('res.users', string='Completed By')
    completed_date = fields.Datetime(string='Completed Date')
    
    # Dependencies
    depends_on_sequence = fields.Integer(string='Depends On')
    can_start = fields.Boolean(compute='_compute_can_start')
    
    # Notes
    notes = fields.Text(string='Notes')
    attachment_ids = fields.Many2many('ir.attachment', string='Attachments')

    @api.depends('depends_on_sequence', 'closing_id.checklist_ids.is_complete')
    def _compute_can_start(self):
        for item in self:
            if not item.depends_on_sequence:
                item.can_start = True
            else:
                depends = item.closing_id.checklist_ids.filtered(
                    lambda x: x.sequence == item.depends_on_sequence
                )
                item.can_start = depends.is_complete if depends else True

    def action_mark_complete(self):
        """Mark item as complete"""
        self.ensure_one()
        if not self.can_start:
            raise UserError("Cannot complete - dependent task not finished")
        self.write({
            'is_complete': True,
            'completed_by': self.env.user.id,
            'completed_date': fields.Datetime.now(),
        })


class FinanceClosingTemplate(models.Model):
    """Closing checklist template per company"""
    _name = 'ipai.finance.closing.template'
    _description = 'Finance Closing Template'

    name = fields.Char(string='Template Name', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True)
    item_ids = fields.One2many('ipai.finance.closing.template.item', 'template_id',
                               string='Checklist Items')
    active = fields.Boolean(default=True)


class FinanceClosingTemplateItem(models.Model):
    """Template item for closing checklist"""
    _name = 'ipai.finance.closing.template.item'
    _description = 'Finance Closing Template Item'
    _order = 'sequence'

    template_id = fields.Many2one('ipai.finance.closing.template', 
                                  required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    name = fields.Char(required=True)
    category = fields.Selection([
        ('finance', 'Finance'),
        ('tax', 'Tax'),
        ('reporting', 'Reporting'),
        ('approval', 'Approval'),
    ], required=True)
    depends_on_sequence = fields.Integer()
    description = fields.Text()


# =============================================================================
# B3: FINANCIAL REPORTING (P2 - 56h)
# =============================================================================
class FinancialReport(models.Model):
    """Financial report generator"""
    _name = 'ipai.financial.report'
    _description = 'Financial Report'

    name = fields.Char(required=True)
    report_type = fields.Selection([
        ('tb', 'Trial Balance'),
        ('bs', 'Balance Sheet'),
        ('pl', 'Income Statement'),
        ('cf', 'Cash Flow Statement'),
        ('ar_aging', 'AR Aging'),
        ('ap_aging', 'AP Aging'),
    ], string='Report Type', required=True)
    
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    date_from = fields.Date(string='From')
    date_to = fields.Date(string='To', required=True)
    
    # Options
    include_zero_balance = fields.Boolean(string='Include Zero Balance')
    show_partner_detail = fields.Boolean(string='Show Partner Detail')
    comparison_date = fields.Date(string='Compare To')

    def action_generate_report(self):
        """Generate the selected report"""
        self.ensure_one()
        if self.report_type == 'tb':
            return self._generate_trial_balance()
        elif self.report_type == 'bs':
            return self._generate_balance_sheet()
        elif self.report_type == 'pl':
            return self._generate_income_statement()
        elif self.report_type == 'cf':
            return self._generate_cash_flow()
        elif self.report_type == 'ar_aging':
            return self._generate_ar_aging()
        elif self.report_type == 'ap_aging':
            return self._generate_ap_aging()

    def _generate_trial_balance(self):
        """Generate trial balance report"""
        accounts = self.env['account.account'].search([
            ('company_id', '=', self.company_id.id)
        ])
        
        data = []
        for account in accounts:
            balance = self._get_account_balance(account, self.date_to)
            if balance or self.include_zero_balance:
                data.append({
                    'code': account.code,
                    'name': account.name,
                    'debit': balance if balance > 0 else 0,
                    'credit': abs(balance) if balance < 0 else 0,
                })
        
        return {
            'type': 'ir.actions.report',
            'report_name': 'ipai_finance_ssc.report_trial_balance',
            'report_type': 'qweb-pdf',
            'data': {'report_data': data, 'date': self.date_to},
        }

    def _get_account_balance(self, account, date):
        """Get account balance as of date"""
        self.env.cr.execute("""
            SELECT COALESCE(SUM(debit) - SUM(credit), 0)
            FROM account_move_line aml
            JOIN account_move am ON am.id = aml.move_id
            WHERE aml.account_id = %s
              AND am.state = 'posted'
              AND aml.date <= %s
              AND aml.company_id = %s
        """, (account.id, date, self.company_id.id))
        result = self.env.cr.fetchone()
        return result[0] if result else 0

    def _generate_balance_sheet(self):
        """Generate balance sheet"""
        # Implementation
        pass

    def _generate_income_statement(self):
        """Generate P&L"""
        # Implementation
        pass

    def _generate_cash_flow(self):
        """Generate cash flow statement"""
        # Implementation
        pass

    def _generate_ar_aging(self):
        """Generate AR aging report"""
        # Implementation
        pass

    def _generate_ap_aging(self):
        """Generate AP aging report"""
        # Implementation
        pass


# =============================================================================
# B4: INTERCOMPANY TRANSACTIONS (P2 - 56h)
# =============================================================================
class IntercompanyTransaction(models.Model):
    """Intercompany transaction tracking"""
    _name = 'ipai.intercompany.transaction'
    _description = 'Intercompany Transaction'
    _inherit = ['mail.thread']

    name = fields.Char(string='Reference', required=True)
    
    # Parties
    source_company_id = fields.Many2one('res.company', string='Source Company', required=True)
    target_company_id = fields.Many2one('res.company', string='Target Company', required=True)
    
    # Journal entries
    source_move_id = fields.Many2one('account.move', string='Source Journal Entry')
    target_move_id = fields.Many2one('account.move', string='Target Journal Entry')
    
    # Amounts
    amount = fields.Monetary(string='Amount', required=True)
    currency_id = fields.Many2one('res.currency', 
                                  default=lambda self: self.env.company.currency_id)
    
    # Status
    state = fields.Selection([
        ('draft', 'Draft'),
        ('pending', 'Pending Match'),
        ('matched', 'Matched'),
        ('eliminated', 'Eliminated'),
    ], default='draft')
    
    # Matching
    matched_date = fields.Date(string='Match Date')
    elimination_move_id = fields.Many2one('account.move', string='Elimination Entry')

    @api.constrains('source_company_id', 'target_company_id')
    def _check_different_companies(self):
        for rec in self:
            if rec.source_company_id == rec.target_company_id:
                raise ValidationError("Source and target company must be different!")

    def action_match(self):
        """Match IC transactions"""
        self.ensure_one()
        # Find matching entry in target company
        # Implementation
        self.write({
            'state': 'matched',
            'matched_date': fields.Date.today()
        })

    def action_create_elimination(self):
        """Create elimination entry for consolidation"""
        self.ensure_one()
        # Implementation
        pass
