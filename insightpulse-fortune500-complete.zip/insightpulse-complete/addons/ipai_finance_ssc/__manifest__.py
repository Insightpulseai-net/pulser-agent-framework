# -*- coding: utf-8 -*-
{
    'name': 'IPAI Finance SSC',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Finance',
    'summary': 'Finance Shared Service Center - Complete SAP S/4HANA parity',
    'description': """
# IPAI Finance SSC Module

Complete Finance Shared Service Center functionality achieving SAP S/4HANA parity.

## Features (Closes Gaps B1-B4: 156 hours)

### B1: Chart of Accounts (Philippine GAAP) - 4h
- Philippine Standard Chart of Accounts (PSCA)
- BIR-compliant account coding
- Multi-company consolidation support

### B2: Month-End Closing - 40h
- 15-step closing checklist with dependencies
- Automated journal entry wizard
- Period lock with override approval

### B3: Financial Reporting - 56h
- Trial Balance, Balance Sheet, P&L
- Cash Flow Statement
- Aged Receivables/Payables

### B4: Intercompany Transactions - 56h
- IC journal entry matching
- Elimination entries automation

## Annual Savings: $920,000 (vs SAP S/4HANA)
    """,
    'author': 'InsightPulse AI',
    'website': 'https://insightpulseai.net',
    'license': 'AGPL-3',
    'depends': ['base', 'account', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'data/account_chart_ph.xml',
        'data/closing_checklist_data.xml',
        'views/finance_ssc_views.xml',
        'wizards/closing_wizard_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
