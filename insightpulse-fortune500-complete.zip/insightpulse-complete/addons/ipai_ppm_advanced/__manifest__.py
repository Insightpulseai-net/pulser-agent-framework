# -*- coding: utf-8 -*-
{
    'name': 'IPAI PPM Advanced',
    'version': '18.0.1.0.0',
    'category': 'Project/Project',
    'summary': 'Project Portfolio Management - Clarity PPM parity',
    'description': """
# IPAI PPM Advanced Module

Complete Project Portfolio Management achieving CA Clarity PPM parity.

## Features (Closes Gaps D1-D5: 176 hours)

### D1: WBS Auto-Numbering (P1 - 24h)
- Hierarchical WBS codes (1.0, 1.1, 1.1.1)
- Parent-child relationship management
- Automatic renumbering on task move

### D2: RAG Status Indicators (P1 - 24h)
- Red/Amber/Green health indicators
- Computed from schedule/budget/scope
- Dashboard roll-up by project/portfolio

### D3: Resource Management (P2 - 48h)
- Capacity planning grid
- Resource utilization tracking
- Skill-based allocation

### D4: Financial Planning (P2 - 48h)
- Project budgeting
- EAC/ETC calculations
- Earned Value Management (EVM)

### D5: Portfolio View (P2 - 32h)
- Multi-project dashboard
- Strategic alignment scoring
- Portfolio balancing tools

## Clarity PPM Parity
- Project Management ✓
- Resource Management ✓
- Financial Management ✓
- Portfolio Management ✓

## Annual Savings: $150,000 (vs CA Clarity)
    """,
    'author': 'InsightPulse AI',
    'website': 'https://insightpulseai.net',
    'license': 'AGPL-3',
    'depends': ['base', 'project', 'hr_timesheet', 'sale_timesheet', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'data/project_stage_data.xml',
        'views/project_views.xml',
        'views/task_views.xml',
        'views/portfolio_views.xml',
        'views/resource_views.xml',
        'reports/project_status_report.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
