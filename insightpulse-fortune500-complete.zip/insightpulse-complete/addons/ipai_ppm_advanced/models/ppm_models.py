# -*- coding: utf-8 -*-
"""
IPAI PPM Advanced - Core Models
Closes gaps: D1-01 (WBS auto-numbering), D2-01 (RAG status indicators),
             D3-* (Resource Management), D4-* (Financial), D5-* (Portfolio)
"""
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from datetime import date, timedelta
import logging

_logger = logging.getLogger(__name__)


# =============================================================================
# D1: WBS AUTO-NUMBERING (P1 - 24h)
# =============================================================================
class ProjectTaskWBS(models.Model):
    """Extends project.task with WBS functionality"""
    _inherit = 'project.task'

    # WBS Fields
    wbs_number = fields.Char(string='WBS', compute='_compute_wbs_number', 
                             store=True, index=True)
    wbs_level = fields.Integer(string='WBS Level', compute='_compute_wbs_level', store=True)
    wbs_sequence = fields.Integer(string='WBS Sequence', default=10)
    
    # Hierarchy
    parent_task_id = fields.Many2one('project.task', string='Parent Task',
                                     domain="[('project_id', '=', project_id)]")
    child_task_ids = fields.One2many('project.task', 'parent_task_id', string='Subtasks')
    
    # RAG Status (D2)
    rag_status = fields.Selection([
        ('green', 'Green - On Track'),
        ('amber', 'Amber - At Risk'),
        ('red', 'Red - Critical'),
        ('gray', 'Gray - Not Started'),
    ], string='RAG Status', compute='_compute_rag_status', store=True)
    
    rag_schedule = fields.Selection([
        ('green', 'On Schedule'),
        ('amber', 'Slipping'),
        ('red', 'Delayed'),
    ], string='Schedule', compute='_compute_rag_schedule', store=True)
    
    rag_budget = fields.Selection([
        ('green', 'Within Budget'),
        ('amber', 'Near Limit'),
        ('red', 'Over Budget'),
    ], string='Budget', compute='_compute_rag_budget', store=True)
    
    rag_scope = fields.Selection([
        ('green', 'Scope OK'),
        ('amber', 'Scope Creep'),
        ('red', 'Major Changes'),
    ], string='Scope', default='green')
    
    # Financial (D4)
    planned_hours = fields.Float(string='Planned Hours')
    actual_hours = fields.Float(string='Actual Hours', compute='_compute_actual_hours')
    planned_cost = fields.Monetary(string='Planned Cost')
    actual_cost = fields.Monetary(string='Actual Cost', compute='_compute_actual_cost')
    
    # EVM Metrics
    bcws = fields.Monetary(string='BCWS (Planned Value)', compute='_compute_evm')
    bcwp = fields.Monetary(string='BCWP (Earned Value)', compute='_compute_evm')
    acwp = fields.Monetary(string='ACWP (Actual Cost)', compute='_compute_evm')
    cpi = fields.Float(string='CPI', compute='_compute_evm', digits=(5, 2))
    spi = fields.Float(string='SPI', compute='_compute_evm', digits=(5, 2))
    eac = fields.Monetary(string='EAC', compute='_compute_evm')
    etc = fields.Monetary(string='ETC', compute='_compute_evm')
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    # Progress
    percent_complete = fields.Float(string='% Complete', digits=(5, 2))
    
    _sql_constraints = [
        ('wbs_unique', 'UNIQUE(project_id, wbs_number)',
         'WBS number must be unique within a project!'),
    ]

    @api.depends('parent_task_id', 'parent_task_id.wbs_number', 'wbs_sequence', 'project_id')
    def _compute_wbs_number(self):
        """Compute hierarchical WBS number"""
        for task in self:
            if task.parent_task_id and task.parent_task_id.wbs_number:
                # Get sibling sequence
                siblings = task.parent_task_id.child_task_ids.sorted('wbs_sequence')
                seq = list(siblings).index(task) + 1 if task in siblings else 1
                task.wbs_number = f"{task.parent_task_id.wbs_number}.{seq}"
            else:
                # Top-level task
                top_tasks = self.search([
                    ('project_id', '=', task.project_id.id),
                    ('parent_task_id', '=', False)
                ]).sorted('wbs_sequence')
                seq = list(top_tasks).index(task) + 1 if task in top_tasks else 1
                task.wbs_number = str(seq)

    @api.depends('wbs_number')
    def _compute_wbs_level(self):
        """Compute WBS level from number of dots"""
        for task in self:
            if task.wbs_number:
                task.wbs_level = task.wbs_number.count('.') + 1
            else:
                task.wbs_level = 1

    @api.depends('rag_schedule', 'rag_budget', 'rag_scope')
    def _compute_rag_status(self):
        """Compute overall RAG from components (worst case)"""
        priority = {'red': 3, 'amber': 2, 'green': 1, 'gray': 0, False: 0}
        
        for task in self:
            components = [task.rag_schedule, task.rag_budget, task.rag_scope]
            # Filter out None/False values
            valid = [c for c in components if c]
            
            if not valid:
                task.rag_status = 'gray'
            else:
                # Worst case wins
                worst = max(valid, key=lambda x: priority.get(x, 0))
                task.rag_status = worst

    @api.depends('date_deadline', 'percent_complete')
    def _compute_rag_schedule(self):
        """Compute schedule RAG based on deadline and progress"""
        for task in self:
            if not task.date_deadline:
                task.rag_schedule = 'green'
                continue
            
            today = date.today()
            deadline = task.date_deadline
            
            if isinstance(deadline, str):
                # Handle string dates
                deadline = fields.Date.from_string(deadline)
            
            days_remaining = (deadline - today).days
            expected_progress = max(0, min(100, (1 - days_remaining / 30) * 100))
            
            if task.percent_complete >= expected_progress:
                task.rag_schedule = 'green'
            elif task.percent_complete >= expected_progress * 0.8:
                task.rag_schedule = 'amber'
            else:
                task.rag_schedule = 'red'

    @api.depends('actual_cost', 'planned_cost')
    def _compute_rag_budget(self):
        """Compute budget RAG based on cost variance"""
        for task in self:
            if not task.planned_cost:
                task.rag_budget = 'green'
                continue
            
            variance = (task.actual_cost / task.planned_cost) if task.planned_cost else 0
            
            if variance <= 0.9:
                task.rag_budget = 'green'
            elif variance <= 1.0:
                task.rag_budget = 'amber'
            else:
                task.rag_budget = 'red'

    def _compute_actual_hours(self):
        """Compute actual hours from timesheets"""
        for task in self:
            task.actual_hours = sum(task.timesheet_ids.mapped('unit_amount'))

    def _compute_actual_cost(self):
        """Compute actual cost from timesheets and expenses"""
        for task in self:
            # Timesheet cost
            timesheet_cost = sum(
                line.unit_amount * line.employee_id.timesheet_cost
                for line in task.timesheet_ids
            )
            # Add expense cost if available
            task.actual_cost = timesheet_cost

    @api.depends('planned_cost', 'actual_cost', 'percent_complete', 'planned_hours')
    def _compute_evm(self):
        """Compute Earned Value Management metrics"""
        for task in self:
            # Planned Value (BCWS) = % of planned work scheduled * Budget
            task.bcws = task.planned_cost
            
            # Earned Value (BCWP) = % complete * Budget
            task.bcwp = task.planned_cost * (task.percent_complete / 100)
            
            # Actual Cost (ACWP)
            task.acwp = task.actual_cost
            
            # Cost Performance Index
            task.cpi = task.bcwp / task.acwp if task.acwp else 0
            
            # Schedule Performance Index
            task.spi = task.bcwp / task.bcws if task.bcws else 0
            
            # Estimate at Completion
            task.eac = task.planned_cost / task.cpi if task.cpi else 0
            
            # Estimate to Complete
            task.etc = task.eac - task.acwp

    def action_update_progress(self):
        """Wizard to update task progress"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Update Progress',
            'res_model': 'ipai.ppm.progress.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_task_id': self.id},
        }


# =============================================================================
# D3: RESOURCE MANAGEMENT (P2 - 48h)
# =============================================================================
class ProjectResource(models.Model):
    """Project resource allocation"""
    _name = 'ipai.ppm.resource'
    _description = 'Project Resource'
    _inherit = ['mail.thread']

    project_id = fields.Many2one('project.project', string='Project', required=True)
    employee_id = fields.Many2one('hr.employee', string='Resource', required=True)
    role_id = fields.Many2one('ipai.ppm.role', string='Role')
    
    # Allocation
    allocation_percent = fields.Float(string='Allocation %', default=100)
    start_date = fields.Date(string='Start Date', required=True)
    end_date = fields.Date(string='End Date')
    
    # Hours
    planned_hours = fields.Float(string='Planned Hours')
    actual_hours = fields.Float(compute='_compute_actual_hours')
    remaining_hours = fields.Float(compute='_compute_remaining_hours')
    
    # Cost
    hourly_rate = fields.Monetary(string='Hourly Rate')
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)

    @api.depends('employee_id', 'project_id')
    def _compute_actual_hours(self):
        """Sum timesheets for this resource on this project"""
        for resource in self:
            timesheets = self.env['account.analytic.line'].search([
                ('project_id', '=', resource.project_id.id),
                ('employee_id', '=', resource.employee_id.id),
            ])
            resource.actual_hours = sum(timesheets.mapped('unit_amount'))

    @api.depends('planned_hours', 'actual_hours')
    def _compute_remaining_hours(self):
        for resource in self:
            resource.remaining_hours = resource.planned_hours - resource.actual_hours


class ProjectRole(models.Model):
    """Project role definitions"""
    _name = 'ipai.ppm.role'
    _description = 'Project Role'

    name = fields.Char(string='Role Name', required=True)
    code = fields.Char(string='Code', required=True)
    default_rate = fields.Monetary(string='Default Rate')
    skill_ids = fields.Many2many('hr.skill', string='Required Skills')
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)


# =============================================================================
# D5: PORTFOLIO VIEW (P2 - 32h)
# =============================================================================
class ProjectPortfolio(models.Model):
    """Project portfolio for multi-project management"""
    _name = 'ipai.ppm.portfolio'
    _description = 'Project Portfolio'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Portfolio Name', required=True)
    code = fields.Char(string='Code')
    manager_id = fields.Many2one('res.users', string='Portfolio Manager')
    
    # Projects
    project_ids = fields.Many2many('project.project', string='Projects')
    project_count = fields.Integer(compute='_compute_project_count')
    
    # Aggregated RAG
    portfolio_rag = fields.Selection([
        ('green', 'Green'),
        ('amber', 'Amber'),
        ('red', 'Red'),
    ], compute='_compute_portfolio_rag', store=True)
    
    # Budget aggregation
    total_budget = fields.Monetary(compute='_compute_financials', store=True)
    total_actual = fields.Monetary(compute='_compute_financials', store=True)
    budget_variance = fields.Monetary(compute='_compute_financials', store=True)
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    # Strategic alignment
    strategic_theme = fields.Selection([
        ('growth', 'Growth'),
        ('efficiency', 'Efficiency'),
        ('compliance', 'Compliance'),
        ('innovation', 'Innovation'),
    ], string='Strategic Theme')
    
    priority = fields.Selection([
        ('1', 'Critical'),
        ('2', 'High'),
        ('3', 'Medium'),
        ('4', 'Low'),
    ], string='Priority', default='3')

    def _compute_project_count(self):
        for portfolio in self:
            portfolio.project_count = len(portfolio.project_ids)

    @api.depends('project_ids.task_ids.rag_status')
    def _compute_portfolio_rag(self):
        """Aggregate RAG from all projects"""
        for portfolio in self:
            all_tasks = portfolio.project_ids.mapped('task_ids')
            
            red_count = len(all_tasks.filtered(lambda t: t.rag_status == 'red'))
            amber_count = len(all_tasks.filtered(lambda t: t.rag_status == 'amber'))
            
            if red_count > 0:
                portfolio.portfolio_rag = 'red'
            elif amber_count > len(all_tasks) * 0.2:  # >20% amber
                portfolio.portfolio_rag = 'amber'
            else:
                portfolio.portfolio_rag = 'green'

    @api.depends('project_ids.task_ids.planned_cost', 'project_ids.task_ids.actual_cost')
    def _compute_financials(self):
        """Aggregate financials from all projects"""
        for portfolio in self:
            all_tasks = portfolio.project_ids.mapped('task_ids')
            portfolio.total_budget = sum(all_tasks.mapped('planned_cost'))
            portfolio.total_actual = sum(all_tasks.mapped('actual_cost'))
            portfolio.budget_variance = portfolio.total_budget - portfolio.total_actual


# =============================================================================
# PROJECT EXTENSION
# =============================================================================
class ProjectProject(models.Model):
    """Extend project.project with PPM features"""
    _inherit = 'project.project'

    # Portfolio link
    portfolio_ids = fields.Many2many('ipai.ppm.portfolio', string='Portfolios')
    
    # Project RAG
    project_rag = fields.Selection([
        ('green', 'Green'),
        ('amber', 'Amber'),
        ('red', 'Red'),
    ], compute='_compute_project_rag', store=True)
    
    # Financial
    project_budget = fields.Monetary(string='Project Budget')
    project_actual = fields.Monetary(compute='_compute_project_actual', store=True)
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)

    @api.depends('task_ids.rag_status')
    def _compute_project_rag(self):
        """Aggregate RAG from tasks"""
        for project in self:
            tasks = project.task_ids
            
            red_count = len(tasks.filtered(lambda t: t.rag_status == 'red'))
            amber_count = len(tasks.filtered(lambda t: t.rag_status == 'amber'))
            
            if red_count > 0:
                project.project_rag = 'red'
            elif amber_count > len(tasks) * 0.2:
                project.project_rag = 'amber'
            else:
                project.project_rag = 'green'

    @api.depends('task_ids.actual_cost')
    def _compute_project_actual(self):
        for project in self:
            project.project_actual = sum(project.task_ids.mapped('actual_cost'))
