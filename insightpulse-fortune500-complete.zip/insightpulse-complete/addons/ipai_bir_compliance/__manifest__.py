# -*- coding: utf-8 -*-
{
    'name': 'IPAI BIR Compliance',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations',
    'summary': 'Philippine BIR Tax Compliance - eFPS Integration',
    'description': """
# IPAI BIR Compliance Module

Complete Philippine Bureau of Internal Revenue (BIR) tax compliance.

## Features (Closes Gaps C1-C5: 153 hours)

### C1: Form 1601-C Monthly WHT (P1 - 16h)
- Creditable Withholding Tax computation
- DAT file generation for eFPS upload
- Monthly deadline tracking (10th of following month)

### C2: Form 2550Q Quarterly VAT (P2 - 32h)
- VAT Input/Output computation
- Standard/Zero-rated sales tracking
- Quarterly DAT file generation

### C3: Form 1702 Annual ITR (P2 - 40h)
- Regular (1702-RT) and Exempt (1702-EX) support
- Reconciliation to Financial Statements
- Annual filing automation

### C4: Form 2307 Certificates (P2 - 32h)
- Creditable WHT Certificate generation
- Supplier 2307 management
- QR code generation for authenticity

### C5: eFPS Integration (P2 - 33h)
- DAT file format compliance
- Submission tracking
- Payment reference recording

## BIR ATC Coverage
- WC: Creditable WHT on compensation
- WI: Creditable WHT on professional fees
- WV: Final WHT on certain payments

## Annual Savings: $30,000 (vs BIR-certified software)
    """,
    'author': 'InsightPulse AI',
    'website': 'https://insightpulseai.net',
    'license': 'AGPL-3',
    'depends': ['base', 'account', 'ipai_finance_ssc'],
    'data': [
        'security/ir.model.access.csv',
        'data/bir_atc_data.xml',
        'data/bir_form_templates.xml',
        'views/bir_form_views.xml',
        'views/bir_2307_views.xml',
        'wizards/dat_generator_views.xml',
        'reports/bir_form_reports.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
