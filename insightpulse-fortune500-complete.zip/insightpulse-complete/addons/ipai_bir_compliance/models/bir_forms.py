# -*- coding: utf-8 -*-
"""
IPAI BIR Compliance - Core Models
Closes gaps: C1-01 (1601-C model), C1-04 (DAT file generator),
             C2-* (2550Q), C3-* (1702), C4-* (2307)
"""
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from datetime import date, timedelta
import logging
import re
import io
import base64

_logger = logging.getLogger(__name__)


# =============================================================================
# C1: FORM 1601-C MONTHLY WHT (P1 - 16h)
# =============================================================================
class BirForm1601C(models.Model):
    """BIR Form 1601-C - Monthly Remittance Return of Creditable Income Tax"""
    _name = 'ipai.bir.form.1601c'
    _description = 'BIR Form 1601-C (Monthly WHT)'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'period_year desc, period_month desc'

    name = fields.Char(string='Reference', compute='_compute_name', store=True)
    company_id = fields.Many2one('res.company', required=True,
                                 default=lambda self: self.env.company)
    
    # Period
    period_month = fields.Selection([
        ('01', 'January'), ('02', 'February'), ('03', 'March'),
        ('04', 'April'), ('05', 'May'), ('06', 'June'),
        ('07', 'July'), ('08', 'August'), ('09', 'September'),
        ('10', 'October'), ('11', 'November'), ('12', 'December'),
    ], string='Month', required=True)
    period_year = fields.Integer(string='Year', required=True,
                                 default=lambda self: date.today().year)
    
    # Company info (from res.company)
    tin = fields.Char(related='company_id.vat', string='TIN')
    registered_name = fields.Char(related='company_id.name', string='Registered Name')
    rdo_code = fields.Char(related='company_id.x_rdo_code', string='RDO Code')
    
    # Amounts
    total_compensation = fields.Monetary(string='Total Compensation', 
                                         compute='_compute_totals', store=True)
    total_tax_withheld = fields.Monetary(string='Tax Withheld',
                                         compute='_compute_totals', store=True)
    surcharge = fields.Monetary(string='Surcharge')
    interest = fields.Monetary(string='Interest')
    compromise = fields.Monetary(string='Compromise')
    total_amount_due = fields.Monetary(string='Total Amount Due',
                                       compute='_compute_amount_due', store=True)
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    # Line items (Schedule 1)
    line_ids = fields.One2many('ipai.bir.form.1601c.line', 'form_id', 
                               string='Schedule 1 - Details')
    
    # Status
    state = fields.Selection([
        ('draft', 'Draft'),
        ('computed', 'Computed'),
        ('filed', 'Filed'),
        ('paid', 'Paid'),
    ], default='draft', tracking=True)
    
    # Filing info
    filing_date = fields.Date(string='Filing Date')
    filing_reference = fields.Char(string='eFPS Reference')
    payment_date = fields.Date(string='Payment Date')
    payment_reference = fields.Char(string='Payment Reference')
    
    # DAT File
    dat_file = fields.Binary(string='DAT File')
    dat_filename = fields.Char(string='DAT Filename')

    _sql_constraints = [
        ('period_unique', 'UNIQUE(company_id, period_month, period_year)',
         'Only one 1601-C per company per period!'),
    ]

    @api.depends('period_month', 'period_year')
    def _compute_name(self):
        for form in self:
            form.name = f"1601-C {form.period_month}/{form.period_year}"

    @api.depends('line_ids.taxable_amount', 'line_ids.tax_withheld')
    def _compute_totals(self):
        for form in self:
            form.total_compensation = sum(form.line_ids.mapped('taxable_amount'))
            form.total_tax_withheld = sum(form.line_ids.mapped('tax_withheld'))

    @api.depends('total_tax_withheld', 'surcharge', 'interest', 'compromise')
    def _compute_amount_due(self):
        for form in self:
            form.total_amount_due = (
                form.total_tax_withheld +
                (form.surcharge or 0) +
                (form.interest or 0) +
                (form.compromise or 0)
            )

    def action_compute(self):
        """Compute WHT from journal entries"""
        self.ensure_one()
        self._populate_from_journals()
        self.write({'state': 'computed'})

    def _populate_from_journals(self):
        """Populate schedule 1 from posted journal entries"""
        # Clear existing lines
        self.line_ids.unlink()
        
        # Date range for the period
        period_start = date(self.period_year, int(self.period_month), 1)
        if int(self.period_month) == 12:
            period_end = date(self.period_year + 1, 1, 1) - timedelta(days=1)
        else:
            period_end = date(self.period_year, int(self.period_month) + 1, 1) - timedelta(days=1)
        
        # Find WHT journal items
        wht_moves = self.env['account.move.line'].search([
            ('company_id', '=', self.company_id.id),
            ('date', '>=', period_start),
            ('date', '<=', period_end),
            ('move_id.state', '=', 'posted'),
            ('account_id.bir_classification', '=', 'liability'),
            ('tax_line_id.type_tax_use', '=', 'purchase'),  # WHT on payments
        ])
        
        # Group by partner and ATC
        grouped = {}
        for line in wht_moves:
            key = (line.partner_id.id, line.tax_line_id.id)
            if key not in grouped:
                grouped[key] = {
                    'partner_id': line.partner_id.id,
                    'atc_id': line.account_id.bir_atc_id.id,
                    'taxable_amount': 0,
                    'tax_withheld': 0,
                }
            grouped[key]['tax_withheld'] += abs(line.balance)
            # Calculate taxable based on rate
            if line.tax_line_id.amount:
                grouped[key]['taxable_amount'] += abs(line.balance) / (line.tax_line_id.amount / 100)
        
        # Create lines
        for data in grouped.values():
            self.env['ipai.bir.form.1601c.line'].create({
                'form_id': self.id,
                **data
            })

    def action_generate_dat(self):
        """Generate DAT file for eFPS upload"""
        self.ensure_one()
        if self.state != 'computed':
            raise UserError("Please compute the form first")
        
        dat_content = self._generate_dat_content()
        
        # Encode and save
        dat_bytes = dat_content.encode('utf-8')
        self.write({
            'dat_file': base64.b64encode(dat_bytes),
            'dat_filename': f"1601C_{self.company_id.vat}_{self.period_year}{self.period_month}.dat"
        })
        
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content?model=ipai.bir.form.1601c&id={self.id}&field=dat_file&filename_field=dat_filename&download=true',
            'target': 'self',
        }

    def _generate_dat_content(self):
        """
        Generate BIR-compliant DAT file content
        
        Format: Header Record + Detail Records
        H,TIN,BRANCH_CODE,RETURN_PERIOD,NO_OF_EMPLOYEES,...
        D,SEQ,EMPLOYEE_TIN,EMPLOYEE_NAME,TAXABLE_INCOME,TAX_WITHHELD,...
        """
        lines = []
        
        # Header record
        header = [
            'H',                                    # Record type
            self._format_tin(self.tin),            # TIN (9 digits)
            '000',                                  # Branch code
            f"{self.period_year}{self.period_month}",  # Return period
            str(len(self.line_ids)),               # Number of employees
            self._format_amount(self.total_compensation),  # Total compensation
            self._format_amount(self.total_tax_withheld),  # Total WHT
            self._format_amount(self.surcharge or 0),
            self._format_amount(self.interest or 0),
            self._format_amount(self.compromise or 0),
            self._format_amount(self.total_amount_due),
        ]
        lines.append(','.join(header))
        
        # Detail records
        for seq, line in enumerate(self.line_ids, 1):
            detail = [
                'D',                                # Record type
                str(seq).zfill(5),                  # Sequence
                self._format_tin(line.partner_id.vat or ''),  # Employee/Supplier TIN
                (line.partner_id.name or '')[:50], # Name (max 50 chars)
                self._format_amount(line.taxable_amount),
                self._format_amount(line.tax_withheld),
            ]
            lines.append(','.join(detail))
        
        return '\n'.join(lines)

    def _format_tin(self, tin):
        """Format TIN to 9 digits (no dashes)"""
        if not tin:
            return '000000000'
        return re.sub(r'[^0-9]', '', tin)[:9].ljust(9, '0')

    def _format_amount(self, amount):
        """Format amount to 2 decimal places"""
        return f"{amount:.2f}"

    def action_file(self):
        """Mark as filed"""
        self.ensure_one()
        self.write({
            'state': 'filed',
            'filing_date': fields.Date.today()
        })

    def action_pay(self):
        """Mark as paid"""
        self.ensure_one()
        self.write({
            'state': 'paid',
            'payment_date': fields.Date.today()
        })


class BirForm1601CLine(models.Model):
    """Schedule 1 line item for 1601-C"""
    _name = 'ipai.bir.form.1601c.line'
    _description = 'BIR Form 1601-C Line'

    form_id = fields.Many2one('ipai.bir.form.1601c', required=True, ondelete='cascade')
    partner_id = fields.Many2one('res.partner', string='Employee/Supplier', required=True)
    atc_id = fields.Many2one('ipai.bir.atc', string='ATC')
    taxable_amount = fields.Monetary(string='Taxable Income')
    tax_withheld = fields.Monetary(string='Tax Withheld')
    currency_id = fields.Many2one(related='form_id.currency_id')


# =============================================================================
# C2: FORM 2550Q QUARTERLY VAT (P2 - 32h)
# =============================================================================
class BirForm2550Q(models.Model):
    """BIR Form 2550Q - Quarterly VAT Return"""
    _name = 'ipai.bir.form.2550q'
    _description = 'BIR Form 2550Q (Quarterly VAT)'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'period_year desc, period_quarter desc'

    name = fields.Char(compute='_compute_name', store=True)
    company_id = fields.Many2one('res.company', required=True,
                                 default=lambda self: self.env.company)
    
    # Period
    period_quarter = fields.Selection([
        ('1', 'Q1 (Jan-Mar)'),
        ('2', 'Q2 (Apr-Jun)'),
        ('3', 'Q3 (Jul-Sep)'),
        ('4', 'Q4 (Oct-Dec)'),
    ], string='Quarter', required=True)
    period_year = fields.Integer(string='Year', required=True,
                                 default=lambda self: date.today().year)
    
    # Company info
    tin = fields.Char(related='company_id.vat')
    
    # Part I - Sales/Receipts
    vatable_sales = fields.Monetary(string='Vatable Sales')
    zero_rated_sales = fields.Monetary(string='Zero-Rated Sales')
    exempt_sales = fields.Monetary(string='Exempt Sales')
    total_sales = fields.Monetary(compute='_compute_totals', store=True)
    
    # Part II - Output VAT
    output_vat = fields.Monetary(string='Output VAT (12%)',
                                 compute='_compute_vat', store=True)
    
    # Part III - Input VAT
    input_vat_purchases = fields.Monetary(string='Input VAT - Purchases')
    input_vat_services = fields.Monetary(string='Input VAT - Services')
    input_vat_capital = fields.Monetary(string='Input VAT - Capital Goods')
    input_vat_carried = fields.Monetary(string='Input VAT Carried Forward')
    total_input_vat = fields.Monetary(compute='_compute_input_vat', store=True)
    
    # Part IV - Tax Due
    vat_payable = fields.Monetary(string='VAT Payable',
                                  compute='_compute_vat_payable', store=True)
    excess_input_vat = fields.Monetary(string='Excess Input VAT',
                                       compute='_compute_vat_payable', store=True)
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('computed', 'Computed'),
        ('filed', 'Filed'),
        ('paid', 'Paid'),
    ], default='draft', tracking=True)
    
    dat_file = fields.Binary(string='DAT File')
    dat_filename = fields.Char()

    @api.depends('period_quarter', 'period_year')
    def _compute_name(self):
        for form in self:
            form.name = f"2550Q Q{form.period_quarter}/{form.period_year}"

    @api.depends('vatable_sales', 'zero_rated_sales', 'exempt_sales')
    def _compute_totals(self):
        for form in self:
            form.total_sales = (
                form.vatable_sales +
                form.zero_rated_sales +
                form.exempt_sales
            )

    @api.depends('vatable_sales')
    def _compute_vat(self):
        for form in self:
            form.output_vat = form.vatable_sales * 0.12  # 12% VAT

    @api.depends('input_vat_purchases', 'input_vat_services', 
                 'input_vat_capital', 'input_vat_carried')
    def _compute_input_vat(self):
        for form in self:
            form.total_input_vat = (
                form.input_vat_purchases +
                form.input_vat_services +
                form.input_vat_capital +
                form.input_vat_carried
            )

    @api.depends('output_vat', 'total_input_vat')
    def _compute_vat_payable(self):
        for form in self:
            net = form.output_vat - form.total_input_vat
            if net > 0:
                form.vat_payable = net
                form.excess_input_vat = 0
            else:
                form.vat_payable = 0
                form.excess_input_vat = abs(net)

    def action_compute(self):
        """Compute VAT from journal entries"""
        self.ensure_one()
        self._populate_from_journals()
        self.write({'state': 'computed'})

    def _populate_from_journals(self):
        """Populate VAT amounts from posted journals"""
        # Implementation similar to 1601-C
        pass

    def action_generate_dat(self):
        """Generate DAT file for eFPS"""
        self.ensure_one()
        # Implementation
        pass


# =============================================================================
# C3: FORM 1702 ANNUAL ITR (P2 - 40h)
# =============================================================================
class BirForm1702(models.Model):
    """BIR Form 1702 - Annual Income Tax Return"""
    _name = 'ipai.bir.form.1702'
    _description = 'BIR Form 1702 (Annual ITR)'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(compute='_compute_name', store=True)
    company_id = fields.Many2one('res.company', required=True,
                                 default=lambda self: self.env.company)
    
    fiscal_year = fields.Integer(string='Fiscal Year', required=True)
    form_type = fields.Selection([
        ('1702-RT', 'Regular (1702-RT)'),
        ('1702-EX', 'Exempt (1702-EX)'),
        ('1702-MX', 'Mixed Income (1702-MX)'),
    ], string='Form Type', required=True, default='1702-RT')
    
    # Gross Income
    gross_sales = fields.Monetary(string='Gross Sales/Receipts')
    cost_of_sales = fields.Monetary(string='Cost of Sales/Services')
    gross_income = fields.Monetary(compute='_compute_gross_income', store=True)
    
    # Deductions
    operating_expenses = fields.Monetary(string='Operating Expenses')
    other_deductions = fields.Monetary(string='Other Deductions')
    total_deductions = fields.Monetary(compute='_compute_deductions', store=True)
    
    # Taxable Income
    taxable_income = fields.Monetary(compute='_compute_taxable_income', store=True)
    income_tax_rate = fields.Float(string='Tax Rate (%)', default=25.0)
    income_tax_due = fields.Monetary(compute='_compute_tax_due', store=True)
    
    # Credits
    creditable_wht = fields.Monetary(string='Creditable WHT')
    quarterly_payments = fields.Monetary(string='Quarterly Payments')
    tax_credits = fields.Monetary(string='Other Tax Credits')
    
    # Net Tax
    net_tax_due = fields.Monetary(compute='_compute_net_tax', store=True)
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('computed', 'Computed'),
        ('filed', 'Filed'),
        ('paid', 'Paid'),
    ], default='draft', tracking=True)

    @api.depends('fiscal_year', 'form_type')
    def _compute_name(self):
        for form in self:
            form.name = f"{form.form_type} {form.fiscal_year}"

    @api.depends('gross_sales', 'cost_of_sales')
    def _compute_gross_income(self):
        for form in self:
            form.gross_income = form.gross_sales - form.cost_of_sales

    @api.depends('operating_expenses', 'other_deductions')
    def _compute_deductions(self):
        for form in self:
            form.total_deductions = form.operating_expenses + form.other_deductions

    @api.depends('gross_income', 'total_deductions')
    def _compute_taxable_income(self):
        for form in self:
            form.taxable_income = form.gross_income - form.total_deductions

    @api.depends('taxable_income', 'income_tax_rate')
    def _compute_tax_due(self):
        for form in self:
            form.income_tax_due = form.taxable_income * (form.income_tax_rate / 100)

    @api.depends('income_tax_due', 'creditable_wht', 'quarterly_payments', 'tax_credits')
    def _compute_net_tax(self):
        for form in self:
            form.net_tax_due = (
                form.income_tax_due -
                form.creditable_wht -
                form.quarterly_payments -
                form.tax_credits
            )


# =============================================================================
# C4: FORM 2307 CERTIFICATES (P2 - 32h)
# =============================================================================
class BirForm2307(models.Model):
    """BIR Form 2307 - Certificate of Creditable Tax Withheld at Source"""
    _name = 'ipai.bir.form.2307'
    _description = 'BIR Form 2307 (WHT Certificate)'
    _inherit = ['mail.thread']
    _order = 'period_end desc'

    name = fields.Char(string='Certificate No.', required=True, copy=False)
    company_id = fields.Many2one('res.company', required=True,
                                 default=lambda self: self.env.company)
    
    # Payor (Company)
    payor_tin = fields.Char(related='company_id.vat', string='Payor TIN')
    payor_name = fields.Char(related='company_id.name', string='Payor Name')
    
    # Payee (Supplier)
    payee_id = fields.Many2one('res.partner', string='Payee', required=True)
    payee_tin = fields.Char(related='payee_id.vat', string='Payee TIN')
    payee_address = fields.Char(related='payee_id.contact_address')
    
    # Period
    period_start = fields.Date(string='Period From', required=True)
    period_end = fields.Date(string='Period To', required=True)
    
    # Amounts
    income_payment = fields.Monetary(string='Income Payment')
    tax_withheld = fields.Monetary(string='Tax Withheld')
    atc_id = fields.Many2one('ipai.bir.atc', string='ATC')
    
    currency_id = fields.Many2one('res.currency',
                                  default=lambda self: self.env.company.currency_id)
    
    # Status
    state = fields.Selection([
        ('draft', 'Draft'),
        ('issued', 'Issued'),
        ('received', 'Received by Payee'),
    ], default='draft', tracking=True)
    
    # QR Code
    qr_code = fields.Binary(string='QR Code', compute='_compute_qr_code')
    
    # Link to source
    source_move_ids = fields.Many2many('account.move', string='Source Journals')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('name') or vals['name'] == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code('ipai.bir.form.2307')
        return super().create(vals_list)

    def _compute_qr_code(self):
        """Generate QR code for verification"""
        for cert in self:
            # QR contains: Cert No, Payor TIN, Payee TIN, Amount, Date
            qr_data = f"{cert.name}|{cert.payor_tin}|{cert.payee_tin}|{cert.tax_withheld}|{cert.period_end}"
            # Implementation: Generate QR using qrcode library
            cert.qr_code = False  # Placeholder

    def action_issue(self):
        """Issue the certificate"""
        self.ensure_one()
        self.write({'state': 'issued'})

    def action_print(self):
        """Print 2307 certificate"""
        return self.env.ref('ipai_bir_compliance.action_report_2307').report_action(self)
